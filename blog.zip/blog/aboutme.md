---
layout: page
title: About me
subtitle: Hành trình bất tận trên con đường Game Dev
---

Tôi là Edu Pham

- Tôi thích game
- Tôi thích chơi game
- Tôi thích lập trình game

Bạnt hích gì?

### Câu chuyện của tôi

Từ từ xây dựng nhé...
