---
layout: post
title: Cách sử dụng Github
subtitle: Chưa hoàn thành
cover-img: 
thumbnail-img: 
share-img: 
tags: [github, tutor]
author: Edu Pham
categories: [Base Skill]
date: 2025-04-24 10:00:00 +0700
---

# Cách sử dụng Github
## Hiểu căn bản về GitHub

## Tạo Repo mới cách 1

- Tại trang github.com 
Nhấn tạo repository mới

![Tạo repository mới](/assets/img/post/github-desktop-new-repository-20.png)

- Tại Repository name
Nhập tên dự án

- Tại Description (optional) (Không bắt buộc)
Nhập mô tả về dự án
Bên dưới thiết lập độ công khai dự án là public hay private. Thường sẽ để private

- Tại Initialize this repository with:
Nên đánh dấu vào Add a README file, đây là file mô tả chung về toàn bộ dự án. Khi mở repo sẽ đọc thấy nó ngay bên dưới

- Tại Add .gitignore
Chọn Unity để bỏ qua các file thư viện unity khi đồng bộ

- Nhấn Create repository
![Tạo repository mới](/assets/img/post/github-desktop-new-repository-21.png)
![Tạo repository mới](/assets/img/post/github-desktop-new-repository-22.png)





---------------
### Tiêu đề cấp 3

**Chữ in đậm**  
*Chữ nghiêng*  
~~Chữ gạch ngang~~

- Danh sách không thứ tự
1. Danh sách có thứ tự

[Liên kết](https://example.com)

`Đoạn mã ngắn`

